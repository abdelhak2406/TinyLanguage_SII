import java.util.ArrayList;

public class AssemblyGenerator {
    ArrayList<Quad> quads;
    boolean erreur ;

    ArrayList<String> code = new ArrayList<String>();

    public AssemblyGenerator(QuadGenerator q){
        quads = q.getQuads();
        this.erreur = q.erreur;
    }

    public void createCode(){
        for (Quad q :quads) {
            if (q.vals[0].equals(":=")){
                ajouter_affectation(q);
            }
            else if (q.vals[0].equals("READ")){
                this.code.add("READ " + q.vals[3]);
            }
            else if (q.vals[0].equals("WRITE")){
                this.code.add("WRITE " + q.vals[3]);
            }
            else {
                ajouter_jump(q);
            }
        }
    }

    public void ajouter_affectation(Quad q){

    }

    public void ajouter_jump(Quad q){

    }

    public void printCode(){
        if (this.erreur){
            Main.print_color("UNE OU PLUSIEURS ERREURS => PAS DE CODE ASSEMBLEUR.");
        }else {
            System.out.println("***** Code assembleur *****");
            for (String s : code) {
                System.out.println(s);
            }
        }
    }
}
