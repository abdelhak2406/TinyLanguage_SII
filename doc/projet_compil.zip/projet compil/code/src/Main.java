import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import interpreter.GramParser;
import interpreter.GramLexer;

import java.io.IOException;


public class Main {

    public static void main(String[] args) throws IOException {
        GramLexer lexer = new GramLexer(CharStreams.fromFileName("./src/program.txt"));
        GramParser parser = new GramParser(new CommonTokenStream(lexer));

        TSGenerator tsGenerator = new TSGenerator();
        QuadGenerator quadGenerator = new QuadGenerator(tsGenerator.ts);

        parser.addParseListener(tsGenerator);
        parser.addParseListener(quadGenerator);

        parser.s();

        OCgenerator OCgenerator = new OCgenerator(quadGenerator);
        OCgenerator.createCode();

        tsGenerator.printTS();
        quadGenerator.printQuads();
        OCgenerator.afficherCode();
    }
    public static void print_color(String s){
        final String ANSI_RED = "\u001B[31m";
        final String ANSI_RESET = "\u001B[0m";

        System.out.println(ANSI_RED + s.toUpperCase() + ANSI_RESET);
    }
}
