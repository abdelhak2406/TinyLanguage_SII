import java.util.ArrayList;

public class Quads {
    ArrayList<Quad> quads = new ArrayList<Quad>();

    public void addQuad(Quad q){
        quads.add(q);
    }
    public Quad getQuad(int index){
        return quads.get(index);
    }
    public void setQuad(int index,String value, int position){
        Quad q = quads.get(index);
        q.set(position,value);
        quads.set(index,q);
    }
    public int size(){
        return quads.size();
    }
    public ArrayList<Quad> getArray(){
        return quads;
    }
}
