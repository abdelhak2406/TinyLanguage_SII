import interpreter.GramBaseListener;


public class AnalyseSementique extends GramBaseListener {
    public TableS ts;

    public AnalyseSementique(TableS ts){
        this.ts = ts;
    }
}
