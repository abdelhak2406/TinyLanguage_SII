import interpreter.GramBaseListener;
import interpreter.GramParser;

public class TSGenerator extends GramBaseListener {
    TableS ts = new TableS();
    String type;

    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_RESET = "\u001B[0m";

    @Override
    public void exitType(GramParser.TypeContext ctx) {
        if(ctx.getText().equals("int_SJ")) type = "int";
        if(ctx.getText().equals("float_SJ")) type = "float";
        if(ctx.getText().equals("string_SJ")) type = "string";
    }

    @Override
    public void exitDec(GramParser.DecContext ctx) {
        // look for the var if it exists
        if (ts.getElement(ctx.ID().getText()) == null){
            // element doesn't exist
            ts.addElement(new TableS.Element(ctx.ID().getText(),1,type,null));
        }
        else{
            System.out.println(ANSI_RED + "DOUBLE DECLARATION DE LA VARIABLE : " + ctx.ID().getText() + ANSI_RESET);
        }
    }

    @Override
    public void exitEdec2(GramParser.Edec2Context ctx) {
        // look for the var if it exists
        if (ts.getElement(ctx.ID().getText()) == null){
            // element doesn't exist
            ts.addElement(new TableS.Element(ctx.ID().getText(),1,type,null));
        }
        else{
            System.out.println(ANSI_RED + "DOUBLE DECLARATION DE LA VARIABLE : " + ctx.ID().getText() + ANSI_RESET);
        }
    }

    public void printTS(){
        System.out.println("***** Table des symboles *****");
        for (int i = 0; i < ts.getSize(); i++) {
            System.out.println(ts.getElement(i));
        }
    }
}
