import interpreter.GramBaseListener;
import interpreter.GramParser;

import java.util.ArrayList;
import java.util.Stack;

public class QuadGenerator extends GramBaseListener {
    Quads quads = new Quads();
    boolean erreur = false;
    TableS ts ;

    int debutsi = -1;
    int debutsinon = -1;
    boolean br_added = false;

    boolean bib_lang = false;
    boolean bib_io = false;
    boolean erreur_lang = false;
    boolean erreur_io = false;

    Stack sgfs = new Stack();

    String type;
    int nbtemp;
    Stack nom = new Stack();
    Stack val = new Stack();
    Stack cond = new Stack();
    Stack nou = new Stack();
    Stack fin = new Stack();

    public QuadGenerator(TableS ts){
        this.ts = ts;
    }

    @Override public void exitBib1(GramParser.Bib1Context ctx) { if(!ctx.getText().equals("")){ bib_lang = true;} }

    @Override public void exitBib2(GramParser.Bib2Context ctx) { if(!ctx.getText().equals("")){ bib_io = true;}}

    @Override
    public void enterAffectation(GramParser.AffectationContext ctx) {
        type = null;
        nbtemp = 0;
    }

    @Override
    public void exitInt(GramParser.IntContext ctx) {
        if(type==null){
            type = "int";
            val.push(ctx.getText());
            nom.push(ctx.getText());
        }
        else{
            if(type.equals("int")){
                val.push(ctx.getText());
                nom.push(ctx.getText());
            }else{
                Main.print_color("Incompatibilité de type à la ligne : " + ctx.getStart().getLine());
                erreur = true;
            }
        }
    }

    @Override
    public void exitFloat(GramParser.FloatContext ctx) {
        if(type==null){
            type = "float";
            val.push(ctx.getText());
            nom.push(ctx.getText());
        }
        else{
            if(type.equals("float")){
                val.push(ctx.getText());
                nom.push(ctx.getText());
            }else{
                Main.print_color("Incompatibilité de type à la ligne : " + ctx.getStart().getLine());
                erreur = true;
            }
        }
    }

    @Override
    public void exitString(GramParser.StringContext ctx) {
        if (!bib_lang){
            if (!erreur_lang){
                Main.print_color("la bibliothèque lang manque");
                this.erreur = true;
                erreur_lang = true;
            }
            return;
        }
        if(type==null){
            type = "String";
            val.push(ctx.getText());
            nom.push(ctx.getText());
        }
        else{
            if(type.equals("String")){
                val.push(ctx.getText());
                nom.push(ctx.getText());
            }else{
                Main.print_color("Incompatibilité de type à la ligne : " + ctx.getStart().getLine());
                erreur = true;
            }
        }
    }

    @Override
    public void exitId(GramParser.IdContext ctx) {
        if (ts.getElement(ctx.getText()) == null){
            this.erreur = true;
            Main.print_color("identificateur non declaré à la ligne : " + ctx.getStart().getLine());
            return;
        }
        if(ts.getElement(ctx.getText()).value==null){
            Main.print_color("Utilisation de variable sans initialisation a la ligne : " + ctx.getStart().getLine());
            erreur = true;
            return;
        }
        if(type==null){
            type = ts.getElement(ctx.getText()).type;
            val.push(ts.getElement(ctx.getText()).value);
            nom.push(ctx.getText());
        }
        else{
            if(type.equals(ts.getElement(ctx.getText()).type)){
                val.push(ts.getElement(ctx.getText()).value);
                nom.push(ctx.getText());
            }else{
                Main.print_color("Incompatibilité de type à la ligne : " + ctx.getStart().getLine());
                erreur = true;
            }
        }
    }

    @Override
    public void exitEsign(GramParser.EsignContext ctx) {
        if (!bib_lang){
            if (!erreur_lang){
                Main.print_color("la bibliothèque lang manque");
                this.erreur = true;
                erreur_lang = true;
            }
            return;
        }
        if(type.equals("string")){
            Main.print_color("Operation non valide pour le type String a la ligne : " + ctx.getStart().getLine());
            erreur = true;
            return;
        }
        if(!erreur) {
            if (type.equals("int")) {
                int i;
                nbtemp++;
                i = Integer.valueOf(val.pop().toString());
                val.push(-i);

                String ch = nom.pop().toString();
                Quad q = new Quad("*",ch,"-1","T"+nbtemp);
                quads.addQuad(q);
                nom.push("T"+nbtemp);
                return;
            }
            if (type.equals("float")) {
                float i;
                nbtemp++;
                i = Float.valueOf(val.pop().toString());
                val.push(-i);

                String ch = nom.pop().toString();
                Quad q = new Quad("*",ch,"-1","T"+nbtemp);
                quads.addQuad(q);
                nom.push("T"+nbtemp);
                return;
            }
        }
    }

    @Override
    public void exitEmul(GramParser.EmulContext ctx) {
        if (!bib_lang){
            if (!erreur_lang){
                Main.print_color("la bibliothèque lang manque");
                this.erreur = true;
                erreur_lang = true;
            }
            return;
        }
        if(type.equals("string")){
            Main.print_color("Operation non valide pour le type String a la ligne : " + ctx.getStart().getLine());
            erreur = true;
            return;
        }
        if(!erreur) {
            if (type.equals("int")) {
                int i, j;
                nbtemp++;
                i = Integer.valueOf(val.pop().toString());
                j = Integer.valueOf(val.pop().toString());
                val.push(j * i);

                String ch2 = nom.pop().toString();
                String ch1 = nom.pop().toString();
                Quad q = new Quad("*",ch1,ch2,"T"+nbtemp);
                quads.addQuad(q);
                nom.push("T"+nbtemp);
                return;
            }
            if (type.equals("float")) {
                float i, j;
                nbtemp++;
                i = Float.valueOf(val.pop().toString());
                j = Float.valueOf(val.pop().toString());
                val.push(j * i);

                String ch2 = nom.pop().toString();
                String ch1 = nom.pop().toString();
                Quad q = new Quad("*",ch1,ch2,"T"+nbtemp);
                quads.addQuad(q);
                nom.push("T"+nbtemp);
                return;
            }
        }
    }

    @Override
    public void exitEdiv(GramParser.EdivContext ctx) {
        if (!bib_lang){
            if (!erreur_lang){
                Main.print_color("la bibliothèque lang manque");
                this.erreur = true;
                erreur_lang = true;
            }
            return;
        }
        if(type.equals("string")){
            Main.print_color("Operation non valide pour le type String a la ligne : " + ctx.getStart().getLine());
            erreur = true;
        }
        if(!erreur) {
            if (type.equals("int")) {
                int i, j;
                nbtemp++;
                i = Integer.valueOf(val.pop().toString());
                j = Integer.valueOf(val.pop().toString());
                if (i == 0) {
                    Main.print_color("division sur 0 a la ligne : " + ctx.getStart().getLine());
                    erreur = true;
                    return;
                }
                val.push(j / i);

                String ch2 = nom.pop().toString();
                String ch1 = nom.pop().toString();
                Quad q = new Quad("/",ch1,ch2,"T"+nbtemp);
                quads.addQuad(q);
                nom.push("T"+nbtemp);
                return;
            }
            if (type.equals("float")) {
                float i, j;
                nbtemp++;
                i = Float.valueOf(val.pop().toString());
                j = Float.valueOf(val.pop().toString());
                if (i == 0) {
                    Main.print_color("division sur 0 a la ligne : " + ctx.getStart().getLine());
                    erreur = true;
                    return;
                }
                val.push(j / i);

                String ch2 = nom.pop().toString();
                String ch1 = nom.pop().toString();
                Quad q = new Quad("/",ch1,ch2,"T"+nbtemp);
                quads.addQuad(q);
                nom.push("T"+nbtemp);
                return;
            }
        }
    }

    @Override
    public void exitEadd(GramParser.EaddContext ctx) {
        if (!bib_lang){
            if (!erreur_lang){
                Main.print_color("la bibliothèque lang manque");
                this.erreur = true;
                erreur_lang = true;
            }
            return;
        }
        if(!erreur) {
            if (type.equals("string")) {
                String i, j;
                nbtemp++;
                i = val.pop().toString();
                j = val.pop().toString();
                val.push(j + i);

                String ch2 = nom.pop().toString();
                String ch1 = nom.pop().toString();
                Quad q = new Quad("+",ch1,ch2,"T"+nbtemp);
                quads.addQuad(q);
                nom.push("T"+nbtemp);
                return;
            }
            if (type.equals("int")) {
                int i,j;
                nbtemp++;
                i = Integer.valueOf(val.pop().toString());
                j = Integer.valueOf(val.pop().toString());
                val.push(j + i);

                String ch2 = nom.pop().toString();
                String ch1 = nom.pop().toString();
                Quad q = new Quad("+",ch1,ch2,"T"+nbtemp);
                quads.addQuad(q);
                nom.push("T"+nbtemp);
                return;
            }
            if (type.equals("float")) {
                float i, j;
                nbtemp++;
                i = Float.valueOf(val.pop().toString());
                j = Float.valueOf(val.pop().toString());
                val.push(j + i);

                String ch2 = nom.pop().toString();
                String ch1 = nom.pop().toString();
                Quad q = new Quad("+",ch1,ch2,"T"+nbtemp);
                quads.addQuad(q);
                nom.push("T"+nbtemp);
                return;
            }
        }
    }

    @Override
    public void exitEsub(GramParser.EsubContext ctx) {
        if (!bib_lang){
            if (!erreur_lang){
                Main.print_color("la bibliothèque lang manque");
                this.erreur = true;
                erreur_lang = true;
            }
            return;
        }
        if(type.equals("string")){
            Main.print_color("Operation non valide pour le type String a la ligne : " + ctx.getStart().getLine());
            erreur = true;
            return;
        }
        if(!erreur) {
            if (type.equals("int")) {
                int i, j;
                nbtemp++;
                i = Integer.valueOf(val.pop().toString());
                j = Integer.valueOf(val.pop().toString());
                val.push(j - i);

                String ch2 = nom.pop().toString();
                String ch1 = nom.pop().toString();
                Quad q = new Quad("-",ch1,ch2,"T"+nbtemp);
                quads.addQuad(q);
                nom.push("T"+nbtemp);
                return;
            }
            if (type.equals("float")) {
                float i, j;
                nbtemp++;
                i = Float.valueOf(val.pop().toString());
                j = Float.valueOf(val.pop().toString());
                val.push(j - i);

                String ch2 = nom.pop().toString();
                String ch1 = nom.pop().toString();
                Quad q = new Quad("-",ch1,ch2,"T"+nbtemp);
                quads.addQuad(q);
                nom.push("T"+nbtemp);
                return;
            }
        }
    }

    // When exiting the affectation we generate the quads.
    @Override
    public void exitAffectation(GramParser.AffectationContext ctx) {
        if (ts.getElement(ctx.ID().getText()) == null){
            this.erreur = true;
            Main.print_color("identificateur non declaré à la ligne : " + ctx.getStart().getLine());
            return;
        }
        if(ts.getElement(ctx.ID().getText()).type!=type){
            Main.print_color("Incompatibilité de type à la ligne : " + ctx.getStart().getLine());
            erreur = true;
            return;
        }
        if(!erreur) {
            String i;
            i = val.pop().toString();
            ts.getElement(ctx.ID().getText()).value = i;

            String ch1 = nom.pop().toString();
            Quad q = new Quad(":=",ch1,"",ctx.ID().getText());
            quads.addQuad(q);
            return;
        }
    }

    ////////////////////////////

    @Override
    public void enterExp2(GramParser.Exp2Context ctx) {
        nbtemp=0;
        type=null;
    }

    @Override
    public void exitEnon(GramParser.EnonContext ctx) {
        int i,j;
        i = Integer.valueOf(cond.pop().toString());
        j = Integer.valueOf(cond.pop().toString());
        cond.push(j);
        cond.push(i);

        if (quads.getQuad(i).get(0).equals("BZ")){
            quads.setQuad(i,"BNZ",0);
        }else {
            if (quads.getQuad(i).get(0).equals("BNZ")){
                quads.setQuad(i,"BZ",0);
            }else{
                if (quads.getQuad(i).get(0).equals("BL")){
                    quads.setQuad(i,"BGE",0);
                }else{
                    if (quads.getQuad(i).get(0).equals("BGE")){
                        quads.setQuad(i,"BL",0);
                    }else{
                        if (quads.getQuad(i).get(0).equals("BLE")){
                            quads.setQuad(i,"BG",0);
                        }else{
                            quads.setQuad(i,"BLE",0);
                        }
                    }
                }
            }
        }
        if (quads.getQuad(j).get(0).equals("BZ")){
            quads.setQuad(j,"BNZ",0);
        }else {
            if (quads.getQuad(j).get(0).equals("BNZ")){
                quads.setQuad(j,"BZ",0);
            }else{
                if (quads.getQuad(j).get(0).equals("BL")){
                    quads.setQuad(j,"BGE",0);
                }else{
                    if (quads.getQuad(j).get(0).equals("BGE")){
                        quads.setQuad(j,"BL",0);
                    }else{
                        if (quads.getQuad(j).get(0).equals("BLE")){
                            quads.setQuad(j,"BG",0);
                        }else{
                            quads.setQuad(j,"BLE",0);
                        }
                    }
                }
            }
        }
    }

    @Override
    public void exitEand(GramParser.EandContext ctx) {
            int i,j;
            i = Integer.valueOf(cond.pop().toString());
            j = Integer.valueOf(cond.pop().toString());
            cond.push(i);
            nou.push(j);
    }

    @Override
    public void exitEor(GramParser.EorContext ctx) {
        int i,j;
        i = Integer.valueOf(cond.pop().toString());
        j = Integer.valueOf(cond.pop().toString());

        while(!nou.empty()){
            int k = Integer.valueOf(nou.pop().toString());
            quads.setQuad(k,""+j,3);
        }
        fin.push(j);

        cond.push(i);
    }

    @Override
    public void exitExp2(GramParser.Exp2Context ctx) {
        String ch2 = nom.pop().toString();
        String ch1 = nom.pop().toString();

        if (ctx.opl().getText().equals("<")){
            Quad q = new Quad("BGE",ch1,ch2,"");
            cond.push(quads.size());
            quads.addQuad(q);
            return;
        }
        if (ctx.opl().getText().equals(">")){
            Quad q = new Quad("BLE",ch1,ch2,"");
            cond.push(quads.size());
            quads.addQuad(q);
            return;
        }
        if (ctx.opl().getText().equals("<=")){
            Quad q = new Quad("BG",ch1,ch2,"");
            cond.push(quads.size());
            quads.addQuad(q);
            return;
        }
        if (ctx.opl().getText().equals(">=")){
            Quad q = new Quad("BL",ch1,ch2,"");
            cond.push(quads.size());
            quads.addQuad(q);
            return;
        }
        if (ctx.opl().getText().equals("=")){
            Quad q = new Quad("BNZ",ch1,ch2,"");
            cond.push(quads.size());
            quads.addQuad(q);
            return;
        }
        if (ctx.opl().getText().equals("!=")){
            Quad q = new Quad("BZ",ch1,ch2,"");
            cond.push(quads.size());
            quads.addQuad(q);
            return;
        }
    }

    @Override
    public void enterEns_affectation1(GramParser.Ens_affectation1Context ctx) {
        int i,j;
        i = Integer.valueOf(cond.pop().toString());

        while(!cond.empty()){
            j = Integer.valueOf(cond.pop().toString());

            if (quads.getQuad(j).get(0).equals("BZ")){
                quads.setQuad(j,"BNZ",0);
            }else {
                if (quads.getQuad(j).get(0).equals("BNZ")){
                    quads.setQuad(j,"BZ",0);
                }else{
                    if (quads.getQuad(j).get(0).equals("BL")){
                        quads.setQuad(j,"BGE",0);
                    }else{
                        if (quads.getQuad(j).get(0).equals("BGE")){
                            quads.setQuad(j,"BL",0);
                        }else{
                            if (quads.getQuad(j).get(0).equals("BLE")){
                                quads.setQuad(j,"BG",0);
                            }else{
                                quads.setQuad(j,"BLE",0);
                            }
                        }
                    }
                }
            }

            quads.setQuad(j,""+quads.size(),3);
        }

        cond.push(i);
    }

    @Override
    public void enterEns_affectation2(GramParser.Ens_affectation2Context ctx) {
        int i;
        i = Integer.valueOf(cond.pop().toString());

        quads.setQuad(i,""+quads.size(),3);
    }

    @Override
    public void exitEsi(GramParser.EsiContext ctx) {
        if(!cond.empty()){
            int i;
            i = Integer.valueOf(cond.pop().toString());

            quads.setQuad(i,""+quads.size(),3);
        }
    }

    //////////////////////////////////


    @Override
    public void exitSgfs(GramParser.SgfsContext ctx) {
        if(ctx.sgf()!=null){
            if(ctx.sgf().getText().equals("%d")){
                sgfs.push("int");
            }
            if(ctx.sgf().getText().equals("%f")){
                sgfs.push("float");
            }
            if(ctx.sgf().getText().equals("%s")){
                sgfs.push("string");
            }
        }
    }

    @Override
    public void exitAll(GramParser.AllContext ctx) {
        if(ctx.sgf()!=null){
            if(ctx.sgf().getText().equals("%d")){
                sgfs.push("int");
            }
            if(ctx.sgf().getText().equals("%f")){
                sgfs.push("float");
            }
            if(ctx.sgf().getText().equals("%s")){
                sgfs.push("string");
            }
        }
    }

    @Override
    public void exitIds(GramParser.IdsContext ctx) {
        if(ctx.ID()!=null){
            if(sgfs.empty()){
                erreur=true;
                Main.print_color("IN/OUT manque de Signe de formatage à la ligne : " + ctx.getStart().getLine());
                return;
            }
            if(ts.getElement(ctx.ID().getText()) == null){
                Main.print_color("identificateur non declaré à la ligne : " + ctx.getStart().getLine());
                erreur = true;
                return;
            }
            if (!erreur){
                nom.push(ctx.ID());
            }
        }
    }

    @Override
    public void exitLec(GramParser.LecContext ctx) {
        if (bib_io==false){
            if (!erreur_io){
                Main.print_color("la bibliothèque io manque");
                this.erreur = true;
                erreur_io = true;
            }
            return;
        }

        if(ts.getElement(ctx.ID().getText()) == null){
            Main.print_color("identificateur non declaré à la ligne : " + ctx.getStart().getLine());
            erreur = true;
            return;
        }
        String i = null;
        if(ctx.sgf().getText().equals("%d")){
            i="int";
        }
        if(ctx.sgf().getText().equals("%f")){
            i="float";
        }
        if(ctx.sgf().getText().equals("%s")){
            i="string";
        }
        if(!ts.getElement(ctx.ID().getText()).type.equals(i)){
            Main.print_color("incompatibilité de SGF à la ligne : " + ctx.getStart().getLine());
            erreur = true;
        }

        if (!erreur){
            Quad q = new Quad("READ", " ", " ", ctx.ID().getText());
            quads.addQuad(q);
            /*if (sgfs.size()!=nom.size()){
                erreur=true;
                Main.print_color("IN/OUT manque de ID ou SGF à la ligne : " + ctx.getStart().getLine());
                return;
            }*/
            while(!nom.empty() && !sgfs.empty()) {
                String n = nom.pop().toString();
                if(!ts.getElement(n).type.equals(sgfs.pop().toString())){
                    Main.print_color("incompatibilité de SGF à la ligne : " + ctx.getStart().getLine());
                    erreur = true;
                }
                q = new Quad("READ", " ", " ", n);
                quads.addQuad(q);
            }
            if(!sgfs.empty()){
                erreur=true;
                Main.print_color("IN/OUT manque de ID à la ligne : " + ctx.getStart().getLine());
                return;
            }
            if(!nom.empty()){
                erreur=true;
                Main.print_color("IN/OUT manque de Signe de formatage à la ligne : " + ctx.getStart().getLine());
                return;
            }

        }
    }

    @Override
    public void exitEcr(GramParser.EcrContext ctx) {
        if (!bib_io){
            if (!erreur_io){
                Main.print_color("la bibliothèque io manque");
                this.erreur = true;
                erreur_io = true;
            }
            return;
        }

        if(ts.getElement(ctx.ID().getText()) == null){
            Main.print_color("identificateur non declaré à la ligne : " + ctx.getStart().getLine());
            erreur = true;
            return;
        }
        String i = sgfs.pop().toString();
        if(!ts.getElement(ctx.ID().getText()).type.equals(i)){
            Main.print_color("incompatibilité de SGF à la ligne : " + ctx.getStart().getLine());
            erreur = true;
        }

        if (!erreur){
            Quad q = new Quad("WRITE", " ", " ", ctx.ID().getText());
            quads.addQuad(q);
            while(!nom.empty() && !sgfs.empty()) {
                String n = nom.pop().toString();
                if(!ts.getElement(n).type.equals(sgfs.pop().toString())){
                    Main.print_color("incompatibilité de SGF à la ligne : " + ctx.getStart().getLine());
                    erreur = true;
                }
                q = new Quad("WRITE", " ", " ", n);
                quads.addQuad(q);
            }
            if(!sgfs.empty()){
                erreur=true;
                Main.print_color("IN/OUT manque de ID à la ligne : " + ctx.getStart().getLine());
                return;
            }
            if(!nom.empty()){
                erreur=true;
                Main.print_color("IN/OUT manque de Signe de formatage à la ligne : " + ctx.getStart().getLine());
                return;
            }
        }
    }

    @Override
    public void exitS(GramParser.SContext ctx) {
        Quad q = new Quad("THE","END"," "," ");
        quads.addQuad(q);
    }

    public void printQuads(){
        if (this.erreur){
            Main.print_color("UNE OU PLUSIEURS ERREURS => PAS DE QUADS.");
        }else{
            ArrayList<Quad> q = quads.getArray();
            System.out.println("***** Quadruplets *****");
            for (int i = 0; i < q.size(); i++) {
                System.out.println(i + " - " + q.get(i));
            }
        }
    }

    public ArrayList<Quad> getQuads(){
        return quads.getArray();
    }
}
