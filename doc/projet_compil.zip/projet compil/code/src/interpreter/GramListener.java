// Generated from D:/M1/compil/projet maj/src\Gram.g4 by ANTLR 4.7.2
package interpreter;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link GramParser}.
 */
public interface GramListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link GramParser#s}.
	 * @param ctx the parse tree
	 */
	void enterS(GramParser.SContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#s}.
	 * @param ctx the parse tree
	 */
	void exitS(GramParser.SContext ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#bib1}.
	 * @param ctx the parse tree
	 */
	void enterBib1(GramParser.Bib1Context ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#bib1}.
	 * @param ctx the parse tree
	 */
	void exitBib1(GramParser.Bib1Context ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#bib2}.
	 * @param ctx the parse tree
	 */
	void enterBib2(GramParser.Bib2Context ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#bib2}.
	 * @param ctx the parse tree
	 */
	void exitBib2(GramParser.Bib2Context ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#class_sj}.
	 * @param ctx the parse tree
	 */
	void enterClass_sj(GramParser.Class_sjContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#class_sj}.
	 * @param ctx the parse tree
	 */
	void exitClass_sj(GramParser.Class_sjContext ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#entete}.
	 * @param ctx the parse tree
	 */
	void enterEntete(GramParser.EnteteContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#entete}.
	 * @param ctx the parse tree
	 */
	void exitEntete(GramParser.EnteteContext ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#modificateur}.
	 * @param ctx the parse tree
	 */
	void enterModificateur(GramParser.ModificateurContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#modificateur}.
	 * @param ctx the parse tree
	 */
	void exitModificateur(GramParser.ModificateurContext ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#liste_dec}.
	 * @param ctx the parse tree
	 */
	void enterListe_dec(GramParser.Liste_decContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#liste_dec}.
	 * @param ctx the parse tree
	 */
	void exitListe_dec(GramParser.Liste_decContext ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#type}.
	 * @param ctx the parse tree
	 */
	void enterType(GramParser.TypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#type}.
	 * @param ctx the parse tree
	 */
	void exitType(GramParser.TypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#dec}.
	 * @param ctx the parse tree
	 */
	void enterDec(GramParser.DecContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#dec}.
	 * @param ctx the parse tree
	 */
	void exitDec(GramParser.DecContext ctx);
	/**
	 * Enter a parse tree produced by the {@code edec2}
	 * labeled alternative in {@link GramParser#dec2}.
	 * @param ctx the parse tree
	 */
	void enterEdec2(GramParser.Edec2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code edec2}
	 * labeled alternative in {@link GramParser#dec2}.
	 * @param ctx the parse tree
	 */
	void exitEdec2(GramParser.Edec2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code e1}
	 * labeled alternative in {@link GramParser#dec2}.
	 * @param ctx the parse tree
	 */
	void enterE1(GramParser.E1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code e1}
	 * labeled alternative in {@link GramParser#dec2}.
	 * @param ctx the parse tree
	 */
	void exitE1(GramParser.E1Context ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#inst}.
	 * @param ctx the parse tree
	 */
	void enterInst(GramParser.InstContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#inst}.
	 * @param ctx the parse tree
	 */
	void exitInst(GramParser.InstContext ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#affectation}.
	 * @param ctx the parse tree
	 */
	void enterAffectation(GramParser.AffectationContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#affectation}.
	 * @param ctx the parse tree
	 */
	void exitAffectation(GramParser.AffectationContext ctx);
	/**
	 * Enter a parse tree produced by the {@code emul}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterEmul(GramParser.EmulContext ctx);
	/**
	 * Exit a parse tree produced by the {@code emul}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitEmul(GramParser.EmulContext ctx);
	/**
	 * Enter a parse tree produced by the {@code epar}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterEpar(GramParser.EparContext ctx);
	/**
	 * Exit a parse tree produced by the {@code epar}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitEpar(GramParser.EparContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ediv}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterEdiv(GramParser.EdivContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ediv}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitEdiv(GramParser.EdivContext ctx);
	/**
	 * Enter a parse tree produced by the {@code eadd}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterEadd(GramParser.EaddContext ctx);
	/**
	 * Exit a parse tree produced by the {@code eadd}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitEadd(GramParser.EaddContext ctx);
	/**
	 * Enter a parse tree produced by the {@code string}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterString(GramParser.StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code string}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitString(GramParser.StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code esub}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterEsub(GramParser.EsubContext ctx);
	/**
	 * Exit a parse tree produced by the {@code esub}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitEsub(GramParser.EsubContext ctx);
	/**
	 * Enter a parse tree produced by the {@code esign}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterEsign(GramParser.EsignContext ctx);
	/**
	 * Exit a parse tree produced by the {@code esign}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitEsign(GramParser.EsignContext ctx);
	/**
	 * Enter a parse tree produced by the {@code id}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterId(GramParser.IdContext ctx);
	/**
	 * Exit a parse tree produced by the {@code id}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitId(GramParser.IdContext ctx);
	/**
	 * Enter a parse tree produced by the {@code float}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterFloat(GramParser.FloatContext ctx);
	/**
	 * Exit a parse tree produced by the {@code float}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitFloat(GramParser.FloatContext ctx);
	/**
	 * Enter a parse tree produced by the {@code int}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterInt(GramParser.IntContext ctx);
	/**
	 * Exit a parse tree produced by the {@code int}
	 * labeled alternative in {@link GramParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitInt(GramParser.IntContext ctx);
	/**
	 * Enter a parse tree produced by the {@code esi}
	 * labeled alternative in {@link GramParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterEsi(GramParser.EsiContext ctx);
	/**
	 * Exit a parse tree produced by the {@code esi}
	 * labeled alternative in {@link GramParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitEsi(GramParser.EsiContext ctx);
	/**
	 * Enter a parse tree produced by the {@code esinon}
	 * labeled alternative in {@link GramParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterEsinon(GramParser.EsinonContext ctx);
	/**
	 * Exit a parse tree produced by the {@code esinon}
	 * labeled alternative in {@link GramParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitEsinon(GramParser.EsinonContext ctx);
	/**
	 * Enter a parse tree produced by the {@code enon}
	 * labeled alternative in {@link GramParser#cd}.
	 * @param ctx the parse tree
	 */
	void enterEnon(GramParser.EnonContext ctx);
	/**
	 * Exit a parse tree produced by the {@code enon}
	 * labeled alternative in {@link GramParser#cd}.
	 * @param ctx the parse tree
	 */
	void exitEnon(GramParser.EnonContext ctx);
	/**
	 * Enter a parse tree produced by the {@code eor}
	 * labeled alternative in {@link GramParser#cd}.
	 * @param ctx the parse tree
	 */
	void enterEor(GramParser.EorContext ctx);
	/**
	 * Exit a parse tree produced by the {@code eor}
	 * labeled alternative in {@link GramParser#cd}.
	 * @param ctx the parse tree
	 */
	void exitEor(GramParser.EorContext ctx);
	/**
	 * Enter a parse tree produced by the {@code e2}
	 * labeled alternative in {@link GramParser#cd}.
	 * @param ctx the parse tree
	 */
	void enterE2(GramParser.E2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code e2}
	 * labeled alternative in {@link GramParser#cd}.
	 * @param ctx the parse tree
	 */
	void exitE2(GramParser.E2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code eand}
	 * labeled alternative in {@link GramParser#cd}.
	 * @param ctx the parse tree
	 */
	void enterEand(GramParser.EandContext ctx);
	/**
	 * Exit a parse tree produced by the {@code eand}
	 * labeled alternative in {@link GramParser#cd}.
	 * @param ctx the parse tree
	 */
	void exitEand(GramParser.EandContext ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#exp2}.
	 * @param ctx the parse tree
	 */
	void enterExp2(GramParser.Exp2Context ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#exp2}.
	 * @param ctx the parse tree
	 */
	void exitExp2(GramParser.Exp2Context ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#opl}.
	 * @param ctx the parse tree
	 */
	void enterOpl(GramParser.OplContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#opl}.
	 * @param ctx the parse tree
	 */
	void exitOpl(GramParser.OplContext ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#ens_affectation1}.
	 * @param ctx the parse tree
	 */
	void enterEns_affectation1(GramParser.Ens_affectation1Context ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#ens_affectation1}.
	 * @param ctx the parse tree
	 */
	void exitEns_affectation1(GramParser.Ens_affectation1Context ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#ens_affectation2}.
	 * @param ctx the parse tree
	 */
	void enterEns_affectation2(GramParser.Ens_affectation2Context ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#ens_affectation2}.
	 * @param ctx the parse tree
	 */
	void exitEns_affectation2(GramParser.Ens_affectation2Context ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#lec}.
	 * @param ctx the parse tree
	 */
	void enterLec(GramParser.LecContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#lec}.
	 * @param ctx the parse tree
	 */
	void exitLec(GramParser.LecContext ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#sgfs}.
	 * @param ctx the parse tree
	 */
	void enterSgfs(GramParser.SgfsContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#sgfs}.
	 * @param ctx the parse tree
	 */
	void exitSgfs(GramParser.SgfsContext ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#ids}.
	 * @param ctx the parse tree
	 */
	void enterIds(GramParser.IdsContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#ids}.
	 * @param ctx the parse tree
	 */
	void exitIds(GramParser.IdsContext ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#ecr}.
	 * @param ctx the parse tree
	 */
	void enterEcr(GramParser.EcrContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#ecr}.
	 * @param ctx the parse tree
	 */
	void exitEcr(GramParser.EcrContext ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#all}.
	 * @param ctx the parse tree
	 */
	void enterAll(GramParser.AllContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#all}.
	 * @param ctx the parse tree
	 */
	void exitAll(GramParser.AllContext ctx);
	/**
	 * Enter a parse tree produced by {@link GramParser#sgf}.
	 * @param ctx the parse tree
	 */
	void enterSgf(GramParser.SgfContext ctx);
	/**
	 * Exit a parse tree produced by {@link GramParser#sgf}.
	 * @param ctx the parse tree
	 */
	void exitSgf(GramParser.SgfContext ctx);
}